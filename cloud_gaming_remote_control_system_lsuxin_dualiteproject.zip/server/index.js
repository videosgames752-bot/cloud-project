import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join, existsSync } from 'path';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const httpServer = createServer(app);

// Configure Socket.IO
const io = new Server(httpServer, {
  cors: {
    origin: "*", 
    methods: ["GET", "POST"],
    credentials: true
  },
  transports: ['websocket', 'polling']
});

const PORT = 3001;
const sessions = new Map();

// --- API: ICE Server Endpoint ---
app.get('/api/ice', (req, res) => {
  const iceServers = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ];

  if (process.env.TURN_URL && process.env.TURN_USERNAME && process.env.TURN_CREDENTIAL) {
    iceServers.push({
      urls: process.env.TURN_URL,
      username: process.env.TURN_USERNAME,
      credential: process.env.TURN_CREDENTIAL
    });
  }

  res.json({ iceServers });
});

// --- SERVE STATIC FILES (PRIORITY FIX) ---

const distPath = join(__dirname, '../dist');
const publicPath = join(__dirname, 'public');

// 1. PRIORITY: Serve React Build (dist) FIRST
if (fs.existsSync(distPath)) {
  console.log('Serving React App from dist');
  app.use(express.static(distPath));
}

// 2. FALLBACK: Serve Vanilla Frontend (server/public) SECOND
if (fs.existsSync(publicPath)) {
  console.log('Serving Vanilla fallback from public');
  app.use(express.static(publicPath));
}

// --- SOCKET.IO LOGIC ---
io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);

  socket.on('create-room', (roomId) => {
    socket.join(roomId);
    sessions.set(roomId, { host: socket.id, clients: new Map() });
    console.log(`Room created: ${roomId}`);
  });

  socket.on('join-room', ({ roomId, userName }) => {
    const session = sessions.get(roomId);
    if (session) {
      socket.join(roomId);
      session.clients.set(socket.id, { name: userName });
      socket.emit('room-joined'); 
      io.to(session.host).emit('client-joined', { id: socket.id, name: userName });
      console.log(`Client ${userName} joined ${roomId}`);
    } else {
      socket.emit('error', 'Invalid Session Code');
    }
  });

  socket.on('chat-message', ({ roomId, message, senderName }) => {
    io.to(roomId).emit('chat-message', {
      id: Date.now().toString(),
      senderName,
      text: message,
      timestamp: Date.now(),
      isHost: sessions.get(roomId)?.host === socket.id
    });
  });

  socket.on('kick-client', ({ clientId, roomId }) => {
    const session = sessions.get(roomId);
    if (session && session.host === socket.id) {
        io.to(clientId).emit('kicked');
        session.clients.delete(clientId);
        const clientSocket = io.sockets.sockets.get(clientId);
        if (clientSocket) clientSocket.leave(roomId);
    }
  });

  socket.on('offer', ({ offer, roomId, target }) => {
    socket.to(target || roomId).emit('offer', { offer, sender: socket.id });
  });

  socket.on('answer', ({ answer, roomId, target }) => {
    socket.to(target || roomId).emit('answer', { answer, sender: socket.id });
  });

  socket.on('ice-candidate', ({ candidate, roomId, target }) => {
    socket.to(target || roomId).emit('ice-candidate', { candidate, sender: socket.id });
  });

  socket.on('disconnect', () => {
    sessions.forEach((session, roomId) => {
        if (session.host === socket.id) {
            io.to(roomId).emit('error', 'Host disconnected');
            sessions.delete(roomId);
        } else if (session.clients.has(socket.id)) {
            session.clients.delete(socket.id);
            io.to(session.host).emit('client-left', socket.id);
        }
    });
  });
});

// --- SPA FALLBACK ---
app.use((req, res) => {
  // Try to serve React index.html first
  if (fs.existsSync(join(distPath, 'index.html'))) {
    res.sendFile(join(distPath, 'index.html'));
  } 
  // Fallback to Vanilla index.html
  else if (fs.existsSync(join(publicPath, 'index.html'))) {
    res.sendFile(join(publicPath, 'index.html'));
  }
  else {
    res.status(404).send('No frontend found. Run "yarn build" to generate the main app.');
  }
});

// Bind to 0.0.0.0 to allow access from other devices on the network
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
