import { io } from 'socket.io-client';

// We use a relative URL ("/") so requests go through the Vite proxy configured in vite.config.ts.
// This ensures the connection works in cloud environments, local networks, and prevents CORS issues.
export const socket = io('/', {
  autoConnect: false,
  path: '/socket.io',
  transports: ['websocket', 'polling'], // Try WebSocket first, fallback to polling
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
});
